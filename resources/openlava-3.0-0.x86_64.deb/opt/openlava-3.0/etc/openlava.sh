#
# openlava.sh:
#   Setup openlava environment variables
#

LSF_ENVDIR=/opt/openlava-3.0/etc
PATH=$PATH:/opt/openlava-3.0/bin
MANPATH=$MANPATH:/opt/openlava-3.0/share/man

export LSF_ENVDIR PATH MANPATH
