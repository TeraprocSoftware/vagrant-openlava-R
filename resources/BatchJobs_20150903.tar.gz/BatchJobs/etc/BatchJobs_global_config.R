cluster.functions = makeClusterFunctionsInteractive()
mail.start = "none"
mail.done = "none"
mail.error = "none"
db.driver = "SQLite"
db.options = list()
debug = FALSE
